<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('paystack_webhook_logs', function (Blueprint $table) {
            $table->id();
            $table->string('event', 100);
            $table->json('payload');
            $table->string('reference', 100)->nullable()->index();
            $table->boolean('processed')->default(false);
            $table->string('process_result', 255)->nullable();
            $table->timestamp('processed_at')->nullable();
            $table->timestamp('created_at')->useCurrent();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('paystack_webhook_logs');
    }
};
