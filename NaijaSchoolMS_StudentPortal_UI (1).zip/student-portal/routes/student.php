<?php
/**
 * NaijaSchoolMS — Student Portal Routes
 * ─────────────────────────────────────
 * All routes are UI-only closures (no controllers required).
 * POST routes redirect back so forms don't 500 when no controller exists yet.
 *
 * Register in routes/web.php:
 *   require __DIR__.'/student.php';
 */

use Illuminate\Support\Facades\Route;

Route::prefix('student')
     ->name('student.')
     ->group(function () {

    // ── Dashboard ──────────────────────────────────────────────
    Route::get('/dashboard', fn () => view('student.dashboard'))
         ->name('dashboard');

    // ── Timetable ──────────────────────────────────────────────
    Route::get('/timetable', fn () => view('student.timetable.index'))
         ->name('timetable.index');

    // ── Results ────────────────────────────────────────────────
    Route::get('/results', fn () => view('student.results.index'))
         ->name('results.index');

    Route::get('/results/report-card', function () {
        return back()->with('success', 'Report card download will be available once wired to the backend.');
    })->name('results.report-card');

    // ── CBT Exams ──────────────────────────────────────────────
    Route::get('/exams', fn () => view('student.cbt.index'))
         ->name('exams.index');

    Route::get('/exams/{exam}/lobby', function ($exam) {
        return view('student.cbt.lobby', ['examId' => $exam]);
    })->name('exams.lobby');

    Route::post('/exams/{exam}/start', function ($exam) {
        return redirect()->route('student.exams.take', 1);
    })->name('exams.start');

    Route::get('/exams/take/{attempt}', function ($attempt) {
        return view('student.cbt.exam', ['attemptId' => $attempt]);
    })->name('exams.take');

    Route::post('/exams/save/{attempt}', function ($attempt) {
        return response()->json(['status' => 'ok']);
    })->name('exams.save');

    Route::post('/exams/{exam}/submit', function ($exam) {
        return redirect()->route('student.results.index')
               ->with('success', 'Exam submitted. Results will be published after marking.');
    })->name('exams.submit');

    Route::get('/exams/result/{attempt}', function ($attempt) {
        return redirect()->route('student.results.index');
    })->name('exams.result');

    // ── Attendance ─────────────────────────────────────────────
    Route::get('/attendance', fn () => view('student.attendance.index'))
         ->name('attendance.index');

    // ── Announcements ──────────────────────────────────────────
    Route::get('/announcements', fn () => view('student.announcements.index'))
         ->name('announcements.index');

    Route::post('/announcements/{announcement}/read', function ($announcement) {
        return response()->json(['status' => 'ok']);
    })->name('announcements.read');

    // ── Profile ────────────────────────────────────────────────
    Route::get('/profile', fn () => view('student.profile.index'))
         ->name('profile.index');

    Route::post('/profile/photo', function () {
        return back()->with('success', 'Profile photo updated successfully.');
    })->name('profile.photo');

    Route::post('/profile/password', function () {
        return back()->with('success', 'Password changed successfully.');
    })->name('profile.password');

});
