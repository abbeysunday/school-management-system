@extends('student.layouts.app')

@section('title', 'Attendance')
@section('page-title', 'My Attendance')
@section('page-sub', 'Track your school attendance for {{ $currentTerm }}')

@php
// ── Dummy Data ────────────────────────────────────────────
$totalDays    = 68;
$daysPresent  = 63;
$daysAbsent   = 3;
$daysLate     = 2;
$attendancePct = round(($daysPresent / $totalDays) * 100, 1);

$months = [
    'Sep 2024' => 'sep',
    'Oct 2024' => 'oct',
    'Nov 2024' => 'nov',
    'Dec 2024' => 'dec',
];
$activeMonth = 'oct';

// Calendar data for October 2024 (starts Tuesday = offset 1)
// Keys are day numbers, values: P=present, A=absent, L=late, H=holiday, W=weekend
$calendarData = [
    'offset' => 1, // Tuesday
    'days'   => 31,
    'status' => [
        1  => 'P',  2  => 'P',  3  => 'P',  4  => 'P',  5  => 'W', // Sat
        6  => 'W',  7  => 'P',  8  => 'P',  9  => 'P',  10 => 'P',
        11 => 'P',  12 => 'W',  13 => 'W',  14 => 'P',  15 => 'A', // absent
        16 => 'P',  17 => 'P',  18 => 'P',  19 => 'W',  20 => 'W',
        21 => 'L',  22 => 'P',  23 => 'P',  24 => 'H',  25 => 'P', // late + holiday
        26 => 'W',  27 => 'W',  28 => 'P',  29 => 'P',  30 => 'P',
        31 => 'P',
    ],
];

// Monthly summary for the term
$monthlySummary = [
    ['month' => 'September 2024', 'total' => 20, 'present' => 19, 'absent' => 0, 'late' => 1, 'pct' => 95.0],
    ['month' => 'October 2024',   'total' => 23, 'present' => 21, 'absent' => 1, 'late' => 1, 'pct' => 91.3],
    ['month' => 'November 2024',  'total' => 20, 'present' => 19, 'absent' => 1, 'late' => 0, 'pct' => 95.0],
    ['month' => 'December 2024',  'total' => 5,  'present' => 4,  'absent' => 1, 'late' => 0, 'pct' => 80.0],
];
@endphp

@section('content')

{{-- Stats --}}
<div class="attendance-stats-grid">
  <div class="att-stat total">
    <div class="att-stat-num">{{ $totalDays }}</div>
    <div class="att-stat-label">School Days</div>
    <div class="att-stat-pct" style="color:var(--text-muted)">This term</div>
  </div>
  <div class="att-stat present">
    <div class="att-stat-num">{{ $daysPresent }}</div>
    <div class="att-stat-label">Days Present</div>
    <div class="att-stat-pct">{{ $attendancePct }}% attendance</div>
  </div>
  <div class="att-stat absent">
    <div class="att-stat-num">{{ $daysAbsent }}</div>
    <div class="att-stat-label">Days Absent</div>
    <div class="att-stat-pct" style="color:var(--clr-danger)">{{ round(($daysAbsent / $totalDays) * 100, 1) }}% absence rate</div>
  </div>
  <div class="att-stat late">
    <div class="att-stat-num">{{ $daysLate }}</div>
    <div class="att-stat-label">Late Arrivals</div>
    <div class="att-stat-pct" style="color:var(--clr-accent)">{{ round(($daysLate / $totalDays) * 100, 1) }}% late rate</div>
  </div>
</div>

{{-- Attendance bar --}}
<div class="card" style="margin-bottom:20px">
  <div class="card-body">
    <div class="att-bar-wrap" style="margin-bottom:0">
      <div class="att-bar-label">
        <span>Overall Attendance Rate</span>
        <span>{{ $attendancePct }}%</span>
      </div>
      <div class="att-progress-bar">
        <div class="att-progress-fill" style="width:{{ $attendancePct }}%"></div>
      </div>
      @if($attendancePct >= 90)
        <div style="font-size:12px;color:var(--clr-active);margin-top:6px;font-weight:600">
          ✓ Excellent attendance — you qualify for all exams and assessments.
        </div>
      @elseif($attendancePct >= 75)
        <div style="font-size:12px;color:var(--clr-accent);margin-top:6px;font-weight:600">
          ⚠ Attendance is acceptable but try to improve. Minimum required: 75%.
        </div>
      @else
        <div style="font-size:12px;color:var(--clr-danger);margin-top:6px;font-weight:600">
          ✕ Attendance is below the 75% minimum. You may be barred from exams.
        </div>
      @endif
    </div>
  </div>
</div>

{{-- Calendar --}}
<div class="card" style="margin-bottom:20px">
  <div class="card-header">
    <div class="card-title">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
      Attendance Calendar
    </div>
    <div class="att-month-selector">
      @foreach($months as $label => $key)
        <button class="att-month-pill {{ $key === $activeMonth ? 'active' : '' }}" onclick="this.parentNode.querySelectorAll('.att-month-pill').forEach(b=>b.classList.remove('active'));this.classList.add('active')">
          {{ $label }}
        </button>
      @endforeach
    </div>
  </div>
  <div class="card-body">

    {{-- Legend --}}
    <div class="att-legend">
      <div class="att-legend-item"><div class="att-legend-dot present"></div> Present</div>
      <div class="att-legend-item"><div class="att-legend-dot absent"></div> Absent</div>
      <div class="att-legend-item"><div class="att-legend-dot late"></div> Late</div>
      <div class="att-legend-item"><div class="att-legend-dot holiday"></div> Holiday / Event</div>
    </div>

    {{-- Calendar grid --}}
    <div class="att-calendar">
      @foreach(['Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $dh)
        <div class="att-cal-header">{{ $dh }}</div>
      @endforeach

      {{-- Empty offset cells --}}
      @for($i = 0; $i < $calendarData['offset']; $i++)
        <div class="att-cal-day empty"></div>
      @endfor

      @for($d = 1; $d <= $calendarData['days']; $d++)
        @php
          $status = $calendarData['status'][$d] ?? 'W';
          $cls = match($status) {
            'P' => 'present', 'A' => 'absent', 'L' => 'late',
            'H' => 'holiday', 'W' => 'weekend', default => 'weekend'
          };
          $title = match($status) {
            'P' => 'Present', 'A' => 'Absent', 'L' => 'Late',
            'H' => 'Holiday', 'W' => 'Weekend', default => ''
          };
        @endphp
        <div class="att-cal-day {{ $cls }}" title="{{ $title }}">{{ $d }}</div>
      @endfor
    </div>

  </div>
</div>

{{-- Monthly Breakdown Table --}}
<div class="card">
  <div class="card-header">
    <div class="card-title">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
      Monthly Breakdown
    </div>
  </div>
  <div class="card-body" style="padding:0">
    <table class="att-table" style="width:100%;border-collapse:collapse">
      <thead>
        <tr>
          <th>Month</th>
          <th>School Days</th>
          <th>Present</th>
          <th>Absent</th>
          <th>Late</th>
          <th>Attendance</th>
        </tr>
      </thead>
      <tbody>
        @foreach($monthlySummary as $m)
          <tr>
            <td style="font-weight:600">{{ $m['month'] }}</td>
            <td>{{ $m['total'] }}</td>
            <td><span class="att-status-badge present">{{ $m['present'] }} days</span></td>
            <td>
              @if($m['absent'] > 0)
                <span class="att-status-badge absent">{{ $m['absent'] }} day{{ $m['absent'] > 1 ? 's' : '' }}</span>
              @else
                <span style="color:var(--text-dim)">—</span>
              @endif
            </td>
            <td>
              @if($m['late'] > 0)
                <span class="att-status-badge late">{{ $m['late'] }} day{{ $m['late'] > 1 ? 's' : '' }}</span>
              @else
                <span style="color:var(--text-dim)">—</span>
              @endif
            </td>
            <td>
              <div style="display:flex;align-items:center;gap:10px">
                <div style="flex:1;max-width:80px;height:6px;background:#f3f4f6;border-radius:99px;overflow:hidden">
                  <div style="height:100%;width:{{ $m['pct'] }}%;background:{{ $m['pct'] >= 90 ? 'var(--clr-active)' : ($m['pct'] >= 75 ? 'var(--clr-accent)' : 'var(--clr-danger)') }};border-radius:99px"></div>
                </div>
                <span style="font-weight:700;font-size:13px;color:{{ $m['pct'] >= 90 ? 'var(--clr-active)' : ($m['pct'] >= 75 ? 'var(--clr-accent)' : 'var(--clr-danger)') }}">{{ $m['pct'] }}%</span>
              </div>
            </td>
          </tr>
        @endforeach
      </tbody>
    </table>
  </div>
</div>

@endsection
