@extends('student.layouts.app')

@section('title', 'My Timetable')
@section('page-title', 'My Timetable')
@section('page-sub', 'Class schedule for {{ $currentTerm }}')

@php
// ── Dummy Data ──────────────────────────────────────────────
use Carbon\Carbon;

$today   = Carbon::now()->dayOfWeekIso; // 1=Mon … 5=Fri
$weekDays = [
    1 => ['name' => 'Mon', 'label' => 'Monday',    'date' => Carbon::now()->startOfWeek()->format('j')],
    2 => ['name' => 'Tue', 'label' => 'Tuesday',   'date' => Carbon::now()->startOfWeek()->addDay()->format('j')],
    3 => ['name' => 'Wed', 'label' => 'Wednesday', 'date' => Carbon::now()->startOfWeek()->addDays(2)->format('j')],
    4 => ['name' => 'Thu', 'label' => 'Thursday',  'date' => Carbon::now()->startOfWeek()->addDays(3)->format('j')],
    5 => ['name' => 'Fri', 'label' => 'Friday',    'date' => Carbon::now()->startOfWeek()->addDays(4)->format('j')],
];

// Subject colour map
$subjectColors = [
    'Mathematics'      => '#16a34a',
    'English Language' => '#2563eb',
    'Basic Science'    => '#7c3aed',
    'Social Studies'   => '#d97706',
    'French'           => '#ea580c',
    'Computer Studies' => '#0891b2',
    'Civic Education'  => '#db2777',
    'Basic Technology' => '#64748b',
    'Agricultural Sci' => '#65a30d',
    'Christian R.K.'   => '#9333ea',
    'Music'            => '#0d9488',
    'PHE'              => '#e11d48',
];

// Weekly schedule: period_number => [day => [...]]
$schedule = [
    // Period 1: 8:00–8:45
    1 => [
        'time'    => '8:00 – 8:45',
        'periods' => [
            1 => ['subject' => 'Mathematics',       'teacher' => 'Mr. Adebayo T.',   'venue' => 'Room 2B'],
            2 => ['subject' => 'English Language',  'teacher' => 'Mrs. Eze C.',      'venue' => 'Room 2B'],
            3 => ['subject' => 'Basic Science',     'teacher' => 'Mr. Umar B.',      'venue' => 'Lab 1'],
            4 => ['subject' => 'Social Studies',    'teacher' => 'Mrs. Nwosu A.',    'venue' => 'Room 2B'],
            5 => ['subject' => 'Mathematics',       'teacher' => 'Mr. Adebayo T.',   'venue' => 'Room 2B'],
        ],
    ],
    // Period 2: 8:45–9:30
    2 => [
        'time'    => '8:45 – 9:30',
        'periods' => [
            1 => ['subject' => 'English Language',  'teacher' => 'Mrs. Eze C.',      'venue' => 'Room 2B'],
            2 => ['subject' => 'Mathematics',       'teacher' => 'Mr. Adebayo T.',   'venue' => 'Room 2B'],
            3 => ['subject' => 'Social Studies',    'teacher' => 'Mrs. Nwosu A.',    'venue' => 'Room 2B'],
            4 => ['subject' => 'Computer Studies',  'teacher' => 'Mr. Balogun D.',   'venue' => 'ICT Lab'],
            5 => ['subject' => 'English Language',  'teacher' => 'Mrs. Eze C.',      'venue' => 'Room 2B'],
        ],
    ],
    // Period 3: 9:30–10:15
    3 => [
        'time'    => '9:30 – 10:15',
        'periods' => [
            1 => ['subject' => 'Basic Science',     'teacher' => 'Mr. Umar B.',      'venue' => 'Lab 1'],
            2 => ['subject' => 'French',            'teacher' => 'Mr. Chukwu K.',    'venue' => 'Room 2B'],
            3 => ['subject' => 'Mathematics',       'teacher' => 'Mr. Adebayo T.',   'venue' => 'Room 2B'],
            4 => ['subject' => 'Basic Science',     'teacher' => 'Mr. Umar B.',      'venue' => 'Lab 1'],
            5 => ['subject' => 'Civic Education',   'teacher' => 'Miss Afolabi R.',  'venue' => 'Room 2B'],
        ],
    ],
    // Short Break: 10:15–10:30
    'break1' => ['time' => '10:15 – 10:30', 'label' => 'Short Break', 'isBreak' => true],
    // Period 4: 10:30–11:15
    4 => [
        'time'    => '10:30 – 11:15',
        'periods' => [
            1 => ['subject' => 'Social Studies',    'teacher' => 'Mrs. Nwosu A.',    'venue' => 'Room 2B'],
            2 => ['subject' => 'Civic Education',   'teacher' => 'Miss Afolabi R.',  'venue' => 'Room 2B'],
            3 => ['subject' => 'English Language',  'teacher' => 'Mrs. Eze C.',      'venue' => 'Room 2B'],
            4 => ['subject' => 'Mathematics',       'teacher' => 'Mr. Adebayo T.',   'venue' => 'Room 2B'],
            5 => ['subject' => 'Basic Science',     'teacher' => 'Mr. Umar B.',      'venue' => 'Lab 1'],
        ],
    ],
    // Period 5: 11:15–12:00
    5 => [
        'time'    => '11:15 – 12:00',
        'periods' => [
            1 => ['subject' => 'French',            'teacher' => 'Mr. Chukwu K.',    'venue' => 'Room 2B'],
            2 => ['subject' => 'Agricultural Sci',  'teacher' => 'Mr. Obi P.',       'venue' => 'Room 2B'],
            3 => ['subject' => 'PHE',               'teacher' => 'Mr. Hassan Y.',    'venue' => 'Sports Field'],
            4 => ['subject' => 'French',            'teacher' => 'Mr. Chukwu K.',    'venue' => 'Room 2B'],
            5 => ['subject' => 'Computer Studies',  'teacher' => 'Mr. Balogun D.',   'venue' => 'ICT Lab'],
        ],
    ],
    // Lunch Break: 12:00–1:00
    'break2' => ['time' => '12:00 – 1:00', 'label' => 'Lunch Break', 'isBreak' => true],
    // Period 6: 1:00–1:45
    6 => [
        'time'    => '1:00 – 1:45',
        'periods' => [
            1 => ['subject' => 'Computer Studies',  'teacher' => 'Mr. Balogun D.',   'venue' => 'ICT Lab'],
            2 => ['subject' => 'Basic Technology',  'teacher' => 'Mr. Emeka S.',     'venue' => 'Tech Lab'],
            3 => ['subject' => 'Christian R.K.',    'teacher' => 'Mrs. Ojo F.',      'venue' => 'Room 2B'],
            4 => ['subject' => 'English Language',  'teacher' => 'Mrs. Eze C.',      'venue' => 'Room 2B'],
            5 => ['subject' => 'Social Studies',    'teacher' => 'Mrs. Nwosu A.',    'venue' => 'Room 2B'],
        ],
    ],
    // Period 7: 1:45–2:30
    7 => [
        'time'    => '1:45 – 2:30',
        'periods' => [
            1 => ['subject' => 'Agricultural Sci',  'teacher' => 'Mr. Obi P.',       'venue' => 'Room 2B'],
            2 => ['subject' => 'Basic Science',     'teacher' => 'Mr. Umar B.',      'venue' => 'Lab 1'],
            3 => ['subject' => 'Music',             'teacher' => 'Mrs. Ikenna T.',   'venue' => 'Music Room'],
            4 => ['subject' => 'PHE',               'teacher' => 'Mr. Hassan Y.',    'venue' => 'Sports Field'],
            5 => ['subject' => 'Agricultural Sci',  'teacher' => 'Mr. Obi P.',       'venue' => 'Room 2B'],
        ],
    ],
];

// Current period detection (for "Now" pill)
$nowPeriod = null;
$nowHour   = Carbon::now()->format('H');
$nowMin    = Carbon::now()->format('i');
$nowTime   = (int)$nowHour * 60 + (int)$nowMin;
$periodTimeRanges = [1 => [480,525], 2 => [525,570], 3 => [570,615], 4 => [630,675], 5 => [675,720], 6 => [780,825], 7 => [825,870]];
foreach ($periodTimeRanges as $p => $range) {
    if ($nowTime >= $range[0] && $nowTime < $range[1]) { $nowPeriod = $p; break; }
}
@endphp

@section('content')

{{-- Week Overview Cards --}}
<div class="weekly-summary" id="weekly-summary">
  @foreach($weekDays as $dayNum => $day)
    <div class="week-day-card {{ $dayNum === $today ? 'today' : '' }} {{ $dayNum === $today ? 'selected' : '' }}"
         data-day="{{ $dayNum }}" onclick="selectDay({{ $dayNum }})">
      <div class="week-day-name">{{ $day['name'] }}</div>
      <div class="week-day-date">{{ $day['date'] }}</div>
      <div class="week-day-count">
        @php $cnt = collect($schedule)->filter(fn($p) => !isset($p['isBreak']) && isset($p['periods'][$dayNum]))->count(); @endphp
        {{ $cnt }} period{{ $cnt !== 1 ? 's' : '' }}
      </div>
    </div>
  @endforeach
</div>

{{-- Day Label --}}
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:8px">
  <h2 style="font-family:'Fraunces',serif;font-size:18px;font-weight:600;color:var(--text-heading)" id="day-label">
    {{ $weekDays[$today]['label'] ?? 'Monday' }}
    @if($today >= 1 && $today <= 5)
      <span style="font-size:13px;font-weight:400;color:var(--text-muted);font-family:'Plus Jakarta Sans',sans-serif"> — Today</span>
    @endif
  </h2>
  <span style="font-size:12.5px;color:var(--text-muted)">{{ $currentTerm }}</span>
</div>

{{-- Timetable Card --}}
<div class="card">
  <div class="card-body" style="padding:0">
    <div id="timetable-body">

      @foreach($schedule as $key => $slot)

        @if(isset($slot['isBreak']))
          {{-- Break row --}}
          <div class="timetable-row break-row" style="min-height:44px">
            <div class="period-time-col" style="border-right:1px solid var(--border)">
              <span class="period-time" style="color:var(--text-dim)">{{ $slot['time'] }}</span>
            </div>
            <div class="period-subject-col">
              <span class="period-break-label">{{ $slot['label'] }}</span>
            </div>
          </div>

        @else
          @php
            $isNow = is_int($key) && $key === $nowPeriod;
          @endphp
          {{-- Period rows — one per day, shown/hidden via JS --}}
          @foreach($weekDays as $dayNum => $day)
            @php $p = $slot['periods'][$dayNum] ?? null; @endphp
            <div class="timetable-row {{ $isNow && $dayNum === $today ? 'now-row' : '' }} day-row"
                 data-day="{{ $dayNum }}"
                 style="{{ $dayNum !== $today ? 'display:none' : '' }}">
              <div class="period-time-col">
                <span class="period-time">{{ $slot['time'] }}</span>
                @if($isNow && $dayNum === $today)
                  <span class="period-now-pill">Now</span>
                @endif
              </div>
              @if($p)
                <div class="period-subject-col">
                  <div class="period-color-bar" style="background:{{ $subjectColors[$p['subject']] ?? '#9ca3af' }}"></div>
                  <div>
                    <div class="period-subject-name">{{ $p['subject'] }}</div>
                    <div class="period-teacher">{{ $p['teacher'] }}</div>
                  </div>
                </div>
                <div class="period-venue-col">
                  <span class="period-venue">{{ $p['venue'] }}</span>
                </div>
              @else
                <div class="period-subject-col">
                  <span style="color:var(--text-dim);font-size:13px;font-style:italic">No class</span>
                </div>
              @endif
            </div>
          @endforeach
        @endif

      @endforeach

    </div>
  </div>
</div>

@endsection

@push('scripts')
<script>
let selectedDay = {{ $today >= 1 && $today <= 5 ? $today : 1 }};
const dayLabels = {1:'Monday',2:'Tuesday',3:'Wednesday',4:'Thursday',5:'Friday'};
const todayNum  = {{ $today }};

function selectDay(dayNum) {
  selectedDay = dayNum;
  // update cards
  document.querySelectorAll('.week-day-card').forEach(c => {
    c.classList.toggle('selected', +c.dataset.day === dayNum);
  });
  // update label
  const label = document.getElementById('day-label');
  label.innerHTML = dayLabels[dayNum] + (dayNum === todayNum ? ' <span style="font-size:13px;font-weight:400;color:var(--text-muted);font-family:\'Plus Jakarta Sans\',sans-serif"> — Today</span>' : '');
  // show/hide rows
  document.querySelectorAll('.day-row').forEach(r => {
    r.style.display = +r.dataset.day === dayNum ? '' : 'none';
  });
}
</script>
@endpush
