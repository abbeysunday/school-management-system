@extends('student.layouts.app')

@section('title', 'Announcements')
@section('page-title', 'Announcements')
@section('page-sub', 'School news and important notices')

@php
$announcements = [
    [
        'id'       => 1,
        'priority' => 'emergency',
        'title'    => 'Emergency: Water Supply Disruption Tomorrow',
        'body'     => 'Due to critical plumbing works in the school compound, there will be no water supply from 7 AM to 3 PM tomorrow Friday, 25th October. All students are advised to come with extra water and water bottles. Food from the canteen will be limited. Students with medical needs should inform their class teacher.',
        'author'   => 'School Administration',
        'date'     => '4 hours ago',
        'read'     => false,
    ],
    [
        'id'       => 2,
        'priority' => 'important',
        'title'    => 'PTA Meeting — Saturday 26th October 2024',
        'body'     => 'Dear parents and guardians, there will be a PTA meeting this Saturday, 26th October 2024 at 10:00 AM in the school hall. Agenda items include first term examination timetable, school fees for next session, and infrastructure updates. All parents are strongly encouraged to attend. Refreshments will be provided.',
        'author'   => 'Mrs. Adunola Fashola (PTA President)',
        'date'     => '1 day ago',
        'read'     => false,
    ],
    [
        'id'       => 3,
        'priority' => 'important',
        'title'    => 'First Term Mid-Term Examination Timetable Released',
        'body'     => 'The timetable for the first term mid-term examinations is now available. Examinations begin on Monday, 4th November 2024 and run through Friday, 8th November. Students are to revise thoroughly. CBT exams for Mathematics, English, and Basic Science will be conducted in the ICT lab in groups. Physical timetables have been posted on all notice boards.',
        'author'   => 'Academic Affairs Office',
        'date'     => '2 days ago',
        'read'     => false,
    ],
    [
        'id'       => 4,
        'priority' => 'normal',
        'title'    => 'Inter-House Sports Day Rescheduled to 8th November',
        'body'     => 'The inter-house sports day originally scheduled for this Friday has been moved to Friday, 8th November 2024 due to the weather forecast and logistics. All house captains should ensure their members are prepared. Attendance is compulsory. Students should wear their house colours.',
        'author'   => 'Sports Director',
        'date'     => '3 days ago',
        'read'     => true,
    ],
    [
        'id'       => 5,
        'priority' => 'normal',
        'title'    => 'Library Opening Hours Extended',
        'body'     => 'Starting from this week, the school library will remain open until 5:00 PM on weekdays to allow students prepare for upcoming examinations. Students wishing to use the library after school must sign in at the library desk and inform their parent/guardian. Library resources including reference books and past question papers are available.',
        'author'   => 'Library Department',
        'date'     => '5 days ago',
        'read'     => true,
    ],
    [
        'id'       => 6,
        'priority' => 'normal',
        'title'    => 'School Fees Reminder — Second Instalment Due',
        'body'     => 'This is a reminder that the second instalment of first term school fees is due by Friday, 1st November 2024. Parents who have not paid are advised to do so promptly to avoid their ward being sent home. Payment can be made via bank transfer or at the school bursary. Receipt must be submitted to the class teacher.',
        'author'   => 'Bursary Department',
        'date'     => '1 week ago',
        'read'     => true,
    ],
];

$unreadCount = collect($announcements)->where('read', false)->count();
@endphp

@section('content')

{{-- Summary bar --}}
<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;flex-wrap:wrap;gap:10px">
  <div style="font-size:13.5px;color:var(--text-muted)">
    Showing <strong style="color:var(--text-heading)">{{ count($announcements) }}</strong> announcements
    @if($unreadCount > 0)
      — <span style="color:var(--clr-primary);font-weight:600">{{ $unreadCount }} unread</span>
    @endif
  </div>
  @if($unreadCount > 0)
    <button class="btn btn-outline btn-sm" onclick="markAllRead()">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
      Mark All as Read
    </button>
  @endif
</div>

{{-- Filter tabs --}}
<div class="ann-filter-tabs">
  <button class="ann-filter-tab active" data-filter="all">All <span style="opacity:.6;font-size:12px">({{ count($announcements) }})</span></button>
  <button class="ann-filter-tab" data-filter="emergency">
    <span style="display:inline-block;width:7px;height:7px;background:var(--clr-danger);border-radius:50%;margin-right:4px"></span>
    Emergency
  </button>
  <button class="ann-filter-tab" data-filter="important">
    <span style="display:inline-block;width:7px;height:7px;background:var(--clr-accent);border-radius:50%;margin-right:4px"></span>
    Important
  </button>
  <button class="ann-filter-tab" data-filter="normal">Normal</button>
</div>

{{-- Announcement list --}}
<div class="ann-list" id="ann-list">

  @foreach($announcements as $ann)
    <div class="ann-card {{ !$ann['read'] ? 'unread' : 'read-card' }} ann-{{ $ann['priority'] }}"
         data-priority="{{ $ann['priority'] }}"
         data-id="{{ $ann['id'] }}"
         onclick="expandAnn(this)">

      <div class="ann-card-header">

        {{-- Priority icon --}}
        <div class="ann-icon {{ $ann['priority'] }}">
          @if($ann['priority'] === 'emergency')
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          @elseif($ann['priority'] === 'important')
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
          @else
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 17H2a3 3 0 0 0 3-3V9a7 7 0 0 1 14 0v5a3 3 0 0 0 3 3zm-8.27 4a2 2 0 0 1-3.46 0"/></svg>
          @endif
        </div>

        <div class="ann-card-meta">
          <div class="ann-card-title">{{ $ann['title'] }}</div>
          <div class="ann-card-byline">
            <span class="ann-priority-badge {{ $ann['priority'] }}">{{ ucfirst($ann['priority']) }}</span>
            <span>{{ $ann['author'] }}</span>
          </div>
        </div>

      </div>

      <div class="ann-card-body">{{ $ann['body'] }}</div>

      <div class="ann-card-footer">
        <span class="ann-card-time">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          {{ $ann['date'] }}
        </span>
        @if(!$ann['read'])
          <button class="ann-mark-read-btn" onclick="event.stopPropagation();markRead(this, {{ $ann['id'] }})">
            Mark as Read
          </button>
        @else
          <span style="font-size:11.5px;color:var(--text-dim)">Read</span>
        @endif
      </div>

    </div>
  @endforeach

</div>

@endsection

@push('scripts')
<script>
// Filter tabs
document.querySelectorAll('.ann-filter-tab').forEach(tab => {
  tab.addEventListener('click', function() {
    document.querySelectorAll('.ann-filter-tab').forEach(t => t.classList.remove('active'));
    this.classList.add('active');
    const filter = this.dataset.filter;
    document.querySelectorAll('.ann-card').forEach(card => {
      card.style.display = (filter === 'all' || card.dataset.priority === filter) ? '' : 'none';
    });
  });
});

function markRead(btn, id) {
  const card = btn.closest('.ann-card');
  card.classList.remove('unread');
  card.classList.add('read-card');
  btn.style.display = 'none';
  // AJAX placeholder
  fetch(`/student/announcements/${id}/read`, { method: 'POST', headers: { 'X-CSRF-TOKEN': document.querySelector('meta[name=csrf-token]')?.content || '' } }).catch(() => {});
}

function markAllRead() {
  document.querySelectorAll('.ann-card.unread').forEach(card => {
    card.classList.remove('unread');
    card.classList.add('read-card');
    const btn = card.querySelector('.ann-mark-read-btn');
    if (btn) btn.style.display = 'none';
  });
}
</script>
@endpush
