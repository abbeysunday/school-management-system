@php
/**
 * Shared dummy data defaults — available on every student portal page.
 * Individual views can override these by defining the same variable in their own @php block.
 * Once the backend is wired, replace with real data from the authenticated user.
 */
$student        = $student        ?? ['first_name' => 'Chidinma', 'last_name' => 'Okafor', 'admission_number' => 'EXC/JSS2/2024/047', 'class' => 'JSS 2B', 'photo' => null];
$currentTerm    = $currentTerm    ?? 'First Term — 2024/2025';
$upcomingExamCount      = $upcomingExamCount      ?? 2;
$unreadAnnouncements    = $unreadAnnouncements    ?? 3;
$school         = $school         ?? (object)['name' => 'Excellence Academy'];
@endphp
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf-token" content="{{ csrf_token() }}">
  <title>@yield('title', 'Student Portal') — {{ $school->name }}</title>
  <meta name="description" content="Student portal for {{ $school->name }}">
  <link rel="icon" href="{{ asset('favicon.ico') }}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link rel="stylesheet" href="{{ asset('css/student.css') }}">
  @stack('styles')
</head>
<body>

<div class="portal-shell">

  @include('student.layouts.partials.sidebar')

  <div class="main-wrapper">

    @include('student.layouts.partials.header')

    <main class="page-content">

      @if(session('success'))
        <div class="result-publish-banner" style="margin-bottom:18px">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
          <span class="result-publish-text">{{ session('success') }}</span>
        </div>
      @endif
      @if(session('error'))
        <div class="result-publish-banner" style="margin-bottom:18px;background:#fee2e2;border-color:#fca5a5">
          <svg viewBox="0 0 24 24" fill="none" stroke="var(--clr-danger)" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
          <span style="color:#991b1b;font-size:13.5px">{{ session('error') }}</span>
        </div>
      @endif

      @yield('content')
    </main>

    @include('student.layouts.partials.footer')

  </div>
</div>

<div class="toast-container" id="toast-container"></div>

<script src="{{ asset('js/student.js') }}"></script>
@stack('scripts')

</body>
</html>
